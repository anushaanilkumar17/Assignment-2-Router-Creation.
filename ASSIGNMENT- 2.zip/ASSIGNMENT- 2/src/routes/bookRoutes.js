const express = require('express');
const booksRouter = express.Router();
function router(nav){

    var books = [

        {
            title:'THE STAND',
            author:'AUTHOR: STEPHEN KING',
            genre:'GENRE: SCIENCE FICTION',
            img:'book 6.jpg',
            description:'The Stand is a post-apocalyptic dark fantasy novel written by American author Stephen King and first published in 1978 by Doubleday. The plot centers on a pandemic of a weaponized strain of influenza that kills almost the entire world population.'
        },
    
        {
            title:'RAISE THE TITANIC',
            author:'AUTHOR: CLIVE CUSSLER',
            genre:'GENRE: ADVENTURE ',
            img:'book 39.jpg',
            description:'It tells the story of efforts to bring the remains of the ill-fated ocean liner RMS Titanic to the surface of the Atlantic Ocean in order to recover a stockpile of an exotic mineral that was being carried aboard. Raise the Titanic! was the third published book to feature the authors protagonist, Dirk Pitt.'
        },
        
        {
            title:'THE PROTOCOL',
            author:'AUTHOR: J.ROBERT KENNEDY',
            genre:'GENRE: ACTION',
            img:'book 42.jpg',
            description:'For two thousand years the Triarii have protected us, influencing history from the crusades to the discovery of America. Descendent from the Roman Empire, they pervade every level of society, and are now in a race with our own government to retrieve an ancient artifact thought to have been lost forever.'
        },
     
        {
            title:'DRACULA',
            author:'AUTHOR: BRAM STOKER',
            genre:'GENRE: HORROR',
            img:'book 25.jpg',
            description:'Dracula is an 1897 Gothic horror novel by Irish author Bram Stoker. It introduced the character of Count Dracula and established many conventions of subsequent vampire fantasy.'
        },

        {
            title:'THE LITTLE PRINCE',
            author:'AUTHOR: ANTOINE DESAINT',
            genre:'GENRE: SHORT STORY',
            img:'book 7.jpg',
            description:'The Little Prince is a novella written by the French Writer, Antoine De Saint-Exupéry. The story begins with the narrator remembering something he drew as a child. As per the narrator, the drawing consisted of an elephant inside the stomach of a snake.'
        },
        
    ];
    
    // var books2 = [
    
    //         {
    //             title:'DRACULA',
    //             author:'AUTHOR: A BRAM STOKER',
    //             genre:'GENRE: HORROR',
    //             img:'book 25.jpg'
    //         },
    
    //         {
    //             title:'THE LITTLE PRINCE',
    //             author:'AUTHOR: ANTOINE DESAINT',
    //             genre:'GENRE: SHORT STORY',
    //             img:'book 7.jpg'
    //         },
        
    //         {
    //             title:'THE PROTOCOL',
    //             author:'AUTHOR: J.ROBERT KENNEDY',
    //             genre:'GENRE: ACTION & ADVENTURE',
    //             img:'book 42.jpg'
    //         }
    // ];
    
    // var books3 = [
    
    //     {
    //         title:'THE BOURNE IDENTITY',
    //         author:'AUTHOR: ROBERT LUDLUM',
    //         genre:'GENRE: ACTION & ADVENTURE',
    //         img:'book 37.jpg'
    //     },
    
    //     {
    //         title:'RAISE THE TITANIC',
    //         author:'AUTHOR: CLIVE CUSSLER',
    //         genre:'GENRE: ACTION & ADVENTURE ',
    //         img:'book 39.jpg'
    //     },
    
    //     {
    //         title:'ICE STATION',
    //         author:'AUTHOR: MATTHEW REILLY',
    //         genre:'GENRE: ACTION & ADVENTURE',
    //         img:'book 38.jpg'
    //     }
    // ];
    
    // var books4 = [
    
    //     {
    //         title:'THE LOST MAN',
    //         author:'AUTHOR: JANE HARPER',
    //         genre:'GENRE: MYSTERY & THRILLER',
    //         img:'book 46.jpg'
    //     },
    
    //     {
    //         title:'KILLING FLOOR',
    //         author:'AUTHOR: LEE CHILD',
    //         genre:'GENRE: MYSTERY & THRILLER',
    //         img:'book 47.jpg'
    //     },
    
    //     {
    //         title:'THE FAMILY UPSTAIRS',
    //         author:'AUTHOR: LISA JEWELL',
    //         genre:'GENRE: MYSTERY & THRILLER',
    //         img:'book 48.jpg'
    //     }
    // ];
    
    
    booksRouter.get('/',function(req,res){
        res.render("books",{
            nav,
            title: 'BOOKS',
            books,
            // books2,
            // books3,
            // books4,

        
        });
    });
    
    booksRouter.get('/:id',function(req,res){
       const id = req.params.id
      
        res.render('book',{
            nav,
            title: 'BOOK',   
            book:books[id],
            
        });
    });

return booksRouter;

}

module.exports = router;
