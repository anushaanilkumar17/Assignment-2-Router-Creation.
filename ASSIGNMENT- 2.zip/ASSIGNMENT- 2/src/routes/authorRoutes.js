 const express = require('express');
const authorRouter = express.Router();
function router(nav){

    var author = [

        
        {
            author:'RABINDRANATH TAGORE',
            dob:'1861-1941',
            img:'author 10.jpg',
            text:'Rabindranath Tagore FRAS, also known by his pen name Bhanu Singha Thakur, and also known by his sobriquets Gurudev, Kabiguru, and Biswakabi, was a Bengali poet, writer, music composer, and painter from the Indian subcontinent.'
        },

        {
           
            author:'RAVINDER SINGH',
            dob:'1982-Present',
            img:'author 16.jpg',
            text:'Ravinder Singh is a software engineer who works with a prominent IT company in India and a bestselling Indian author of nine novels. He was brought up in a very small town of Orissa called Burla.'
        },
    
        {
            author:'AMITAV GHOSH',
            dob:'1956-Present',
            img:'author 15.jpg',
            text:'Amitav Ghosh is an Indian writer and the winner of the 54th Jnanpith award, best known for his work in English fiction. '
        },
        {
            author:'ARUNDHATI ROY',
            dob:'1961-Present',
            img:'author 14.jpg',
            text:'Suzanna Arundhati Roy is an Indian author best known for her novel The God of Small Things, which won the Man Booker Prize for Fiction in 1997 and became the best-selling book by a non-expatriate Indian author. She is also a political activist involved in human rights and environmental causes.'
        },


        {
            author:'KAMALA SURAYYA',
            dob:'1934-2009',
            img:'author 20.jpg',
            text:'Kamala Surayya, popularly known by her one-time pen name Madhavikutty and married name Kamala Das, was an Indian English poet as well as a leading Malayalam author from Kerala, India.'
        },

        
        {
            author:'O N V KURUP',
            dob:'1931-2016',
            img:'author 21.jpg',
            text:'Dr.Ottaplakkal Neelakandan Velu Kurup, popularly known as O. N. V. Kurup or simply and endearingly O. N. V., was a Malayalam poet and lyricist from Kerala, India, who won the Jnanpith Award, the highest literary award in India for the year 2007. '
        }

        
    ];
  
    authorRouter.get('/',function(req,res){
        res.render("author",{
            nav,
            title: 'AUTHORS',
            author,
           
        
        });
    });
    
    authorRouter.get('/:auth',function(req,res){
       const auth = req.params.auth
      
        res.render('authorSingle',{
            nav,
            title: 'AUTHOR',   
            authorSingle:author[auth],
            
        });
    });

return authorRouter;

}

module.exports = router;